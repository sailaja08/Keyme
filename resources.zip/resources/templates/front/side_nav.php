
<div class="col-md-3">
    <p class="lead">KeyMe Store</p>
    <div class="list-group">

    	<?php 

    		get_categories();

    	 ?>

    </div>
</div>
